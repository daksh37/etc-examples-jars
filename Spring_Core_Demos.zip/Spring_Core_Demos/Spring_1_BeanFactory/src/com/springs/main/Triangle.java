package com.springs.main;

public class Triangle {
	
	public void draw(){
		
		System.out.println("Triangle drawn by Spring framenwork ");
	}

}
