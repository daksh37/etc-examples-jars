package com.spring;

public class Circle {
	
	private Point centerPoint;
	private int radious;
	
	
	public Circle(Point centerPoint,int radious){
		this.centerPoint=centerPoint;
		this.radious=radious;
	}
	
	public Point getCenterPoint() {
		return centerPoint;
	}
	public void setCenterPoint(Point centerPoint) {
		this.centerPoint = centerPoint;
	}
	public int getRadious() {
		return radious;
	}
	public void setRadious(int radious) {
		this.radious = radious;
	}
	
	public void draw(){
		
		System.out.println("Circle is drawn with center("+centerPoint.getX()+","+centerPoint.getY()+") and radious "+getRadious());
	}

}
