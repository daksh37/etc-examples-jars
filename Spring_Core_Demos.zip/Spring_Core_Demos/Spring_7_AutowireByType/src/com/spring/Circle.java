package com.spring;

public class Circle {
	
	private Point centerPoint;
	private int radious;
	
	public Point getCenterPoint() {
		return centerPoint;
	}
	public void setCenterPoint(Point centerPoint) {
		this.centerPoint = centerPoint;
	}
	public int getRadious() {
		return radious;
	}
	public void setRadious(int radious) {
		this.radious = radious;
	}
	
	public void draw(){
		
		System.out.println("Circle is drawn with center("+centerPoint.getX()+","+centerPoint.getY()+") and radious "+getRadious());
	}

}
