package com.pradeep.main;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Circle implements Shape {

	private Point center;

	public Point getCenter() {
		return center;
	}
	@Resource(name="pointC")
	/* @Resource is same as autowire by name even if you do not specify
	    name attribute to it and there is a point bean with name center it can 
	    pick that up.  */
	
	public void setCircle(Point circle) {
		this.center = circle;
	}
	public void draw()	{
		System.out.println("center is ("+getCenter().getX()+","+getCenter().getY()+")");
	}
	@PostConstruct
	public void initializeCircle()	{
		System.out.println("circle is initialized..");
	}
	@PreDestroy
	public void destroyCircle()
	{
		System.out.println("circle is destroyed..");
	}
	
}
