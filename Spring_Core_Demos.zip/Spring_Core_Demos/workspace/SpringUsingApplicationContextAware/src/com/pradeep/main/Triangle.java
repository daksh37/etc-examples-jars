package com.pradeep.main;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Triangle implements ApplicationContextAware,BeanNameAware{

	private Point pointA;
	private Point pointB;
	private Point pointC;
	private ApplicationContext ctx=null;
	private String beanName;
	
	public Point getPointA() {
		return pointA;
	}
	public void setPointA(Point pointA) {
		this.pointA = pointA;
	}
	public Point getPointB() {
		return pointB;
	}
	public void setPointB(Point pointB) {
		this.pointB = pointB;
	}
	public Point getPointC() {
		return pointC;
	}
	public void setPointC(Point pointC) {
		this.pointC = pointC;
	}

	public void draw()
	{
		System.out.println("PointA = ("+getPointA().getX()+","+getPointA().getY()+")");
		System.out.println("PointB = ("+getPointB().getX()+","+getPointB().getY()+")");
		System.out.println("PointC = ("+getPointC().getX()+","+getPointC().getY()+")");
		
	}
	@Override
	public void setApplicationContext(ApplicationContext context)
			throws BeansException {
		// TODO Auto-generated method stub
		
		this.ctx=context;
		Point p1=(Point) ctx.getBean("pointA");
		Point p2=(Point) ctx.getBean("pointB");
		Point p3=(Point) ctx.getBean("pointC");
		
		p1.setX(40);
		p1.setY(45);
		
		Triangle t=(Triangle) ctx.getBean("tri");
		
		t.setPointA(p1);
		t.setPointB(p2);
		t.setPointC(p3);
	}
	@Override
	public void setBeanName(String BeanName) {
		// TODO Auto-generated method stub
		this.beanName=BeanName;
		System.out.println("Bean Name Is : "+BeanName);
		
	}
}

