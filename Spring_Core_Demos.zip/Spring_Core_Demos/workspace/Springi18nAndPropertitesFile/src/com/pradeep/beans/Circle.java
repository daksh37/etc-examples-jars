package com.pradeep.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

public class Circle implements Shape{

	private Point center;
	@Autowired
	private MessageSource messageSource;
	
	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public Point getCenter() {
		return center;
	}

	public void setCenter(Point center) {
		this.center = center;
	}
	
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("center is ("+getCenter().getX()+","+getCenter().getY()+")");
		
		System.out.println(this.messageSource.getMessage("Drawing.circle",null,"Default Drawing-message",null));
		//System.out.println(this.messageSource.getMessage("Drawing.point",new Object[]{getCenter().getX(),getCenter().getY()},"Default point-message",null));
		//System.out.println(this.messageSource.getMessage("mymsg",null,"default-message",null));
			
	}
	
}
