package com.pradeep.model;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;



public class CustomerDAO {
	
	public static boolean insertData(SignUp obj)
	{
		
		SessionFactory  sesssionfactory=HibernateUtill.getSf();
		Session s=sesssionfactory.openSession();
		Transaction tx= s.beginTransaction();
		s.save(obj);
		tx.commit();
		System.out.println("DONE!!!!!!!!!!");
		return true;
		
		
	}

}
