package com.pradeep.model;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;


import com.pradeep.controller.LoginAction;

public class LoginDAO {
	
	public static boolean validateUser(LoginAction a)
	{
		String user=a.getUsername();
		System.out.println(user);
		String pass=a.getPassword();
		System.out.println(pass);
		SessionFactory  sesssionfactory=HibernateUtill.getSf();
		Session s=sesssionfactory.openSession();
		s.beginTransaction();
		Query queryResult=s.createQuery("from SignUp where username= :user and password=:pass");
		queryResult.setString("user", user);
		queryResult.setString("pass", pass);
		System.out.println("good job...");
		
		@SuppressWarnings("rawtypes")
		List l=queryResult.list();
		System.out.println(l.size());
		
		if(l.size()==0)
		{
			return false;
		}
		else{
			//SignUp s1=(SignUp) (l.iterator().next());
			//System.out.println(s1.getUsername());
			//System.out.println(s1.getPassword());
			
			
			
			
				return true;
			
		
	
	}

	}
}
