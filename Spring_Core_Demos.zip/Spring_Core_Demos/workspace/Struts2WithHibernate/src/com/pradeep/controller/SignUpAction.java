package com.pradeep.controller;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.pradeep.model.CustomerDAO;
import com.pradeep.model.SignUp;


public class SignUpAction extends ActionSupport implements ModelDriven<SignUp>{

	private static final long serialVersionUID = 1L;
	
	
	private String fname;
	private String lname;
	private String email;
	private String username;
	private String password;
	
	SignUp signup=new SignUp();
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUsername() {
		return username;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String execute()
	{
		if(CustomerDAO.insertData(this.getModel()))
		{
		return SUCCESS;
		}
		return ERROR;
	}
	
	@Override
	public SignUp getModel() {
		// TODO Auto-generated method stub
		return signup;
	}
	

}
