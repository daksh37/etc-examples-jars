package com.pradeep.controller;

import com.opensymphony.xwork2.ActionSupport;


import com.pradeep.model.LoginDAO;


public class LoginAction extends ActionSupport {
	
	
	private static final long serialVersionUID = -4416716381825005045L;
	
	private String username;
	private String password;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String execute()
	{
		if(LoginDAO.validateUser(this))
		{
		return SUCCESS;
		}
		return ERROR;
	}
	
	public void validate()
	{
		System.out.println(getUsername().length());
		System.out.println(getPassword().length());
		if(getUsername().length()==0){
			
			addFieldError(username, "user name is required..");
		}
		if(getPassword().length()==0) {
			addFieldError(password, "password is required...");
		}
	}
}
