package com.pradeep.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		Triangle triangle=(Triangle)ctx.getBean("mytriangle");
		triangle.draw();
	}

}
