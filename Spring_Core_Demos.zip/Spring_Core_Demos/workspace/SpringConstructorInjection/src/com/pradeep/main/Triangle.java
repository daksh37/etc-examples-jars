package com.pradeep.main;

public class Triangle {

	private String type;
	private int height;
	
	/*public Triangle(String type,int height){
		System.out.println("cons...");
		this.type=type;
		this.height=height;
	}*/
	
	public Triangle(int height,String type){
		System.out.println("consss");
		this.type=type;
		this.height=height;
	}

	public Triangle(String type){
		System.out.println("string value");
		this.type=type;
	}
	
	public Triangle(int height){
		System.out.println("integer value");
		this.height=height;
	}
	
	public int getHeight() {
		return height;
	}
	
	public String getType() {
		return type;
	}

	public void draw()
	{
		System.out.println(getType()+" Triangle Drawn of height.."+getHeight());
	}
}
