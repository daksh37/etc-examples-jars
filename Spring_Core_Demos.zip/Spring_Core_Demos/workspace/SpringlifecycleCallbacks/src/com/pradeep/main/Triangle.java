package com.pradeep.main;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;


public class Triangle /*implements InitializingBean,DisposableBean*/{

	private String type;
	private int height;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	
	public void draw()
	{
		System.out.println(getType()+" triangle is drawn of height "+getHeight());
		
	}
	/*@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		
		System.out.println("inside disposable beans destroy method...");
		
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("inside initiliazation beans init method...");
	}*/
	
	public void myInit()
	{
		System.out.println("inside my init method....");
	}
	
	public void myDestroy()
	{
		System.out.println("inside my destroy.....");
	}
}
