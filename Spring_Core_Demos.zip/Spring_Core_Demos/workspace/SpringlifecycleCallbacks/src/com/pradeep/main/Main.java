package com.pradeep.main;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AbstractApplicationContext ctx= new ClassPathXmlApplicationContext("spring.xml");
		ctx.registerShutdownHook();
		Triangle t=(Triangle) ctx.getBean("tri");
		t.draw();
		
	}

}
