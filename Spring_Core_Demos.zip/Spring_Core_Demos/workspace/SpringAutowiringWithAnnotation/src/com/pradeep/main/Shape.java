package com.pradeep.main;

public interface Shape {
	
	public void draw();

}
