package com.pradeep.main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Circle implements Shape {

	
	private Point center;

	public Point getCenter() {
		return center;
	}

	@Autowired
	@Qualifier("circlerelated")
	public void setCircle(Point circle) {
		this.center = circle;
	}
	
	public void draw()
	{
		System.out.println("center is ("+getCenter().getX()+","+getCenter().getY()+")");
	}
	
	
}
