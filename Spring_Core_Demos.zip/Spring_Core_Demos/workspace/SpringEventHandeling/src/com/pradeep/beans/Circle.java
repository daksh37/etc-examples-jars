package com.pradeep.beans;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;

public class Circle implements Shape,ApplicationEventPublisherAware{

	private Point center;
	private ApplicationEventPublisher publisher;
	
	
	public Point getCenter() {
		return center;
	}


	public void setCenter(Point center) {
		this.center = center;
	}


	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("drawing circle....");
		System.out.println("Circle center is ("+getCenter().getX()+","+getCenter().getY()+")");
		DrawEvent drawEvent=new DrawEvent(this);
		publisher.publishEvent(drawEvent);
		
		
	}


	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher publisher) {
		// TODO Auto-generated method stub
		this.publisher=publisher;
	}

}
