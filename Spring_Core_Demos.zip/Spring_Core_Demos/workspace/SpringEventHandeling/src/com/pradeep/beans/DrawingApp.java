package com.pradeep.beans;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class DrawingApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		Shape shape = (Shape) ctx.getBean("circle");
		
		shape.draw();
		
		
	}

}
