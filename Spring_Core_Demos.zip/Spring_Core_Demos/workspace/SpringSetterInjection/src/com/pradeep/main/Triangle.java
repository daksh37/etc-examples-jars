package com.pradeep.main;

public class Triangle {
	
	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		System.out.println("set method called");
		this.type = type;
	}
	
	public void draw()
	{
		System.out.println(getType()+" Triangle Drawn....");
	}
}
