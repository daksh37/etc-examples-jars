package com.pradeep.main;

import java.util.List;

public class Triangle{

	private List<Point> pointlist;


	public List<Point> getPointlist() {
		return pointlist;
	}


	public void setPointlist(List<Point> pointlist) {
		this.pointlist = pointlist;
	}





	public void draw()
	{
		for(Point point:pointlist)
		{
		System.out.println("point  = ("+point.getX()+","+point.getY()+")");
		}
	}
	
}

