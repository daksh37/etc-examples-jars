package com.pradeep.hello;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.pradeep.beans.Shape;

public class DrawingApp {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*@SuppressWarnings("deprecation")
		BeanFactory beanFactory= new XmlBeanFactory(new FileSystemResource("spring.xml"));
		Shape shape=(Shape) beanFactory.getBean("shape");*/
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		Shape shape = (Shape) ctx.getBean("triangle");
		shape.draw();
		
		
	}

}
