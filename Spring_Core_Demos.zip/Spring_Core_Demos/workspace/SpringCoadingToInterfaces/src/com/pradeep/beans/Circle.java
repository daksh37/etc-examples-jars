package com.pradeep.beans;

public class Circle implements Shape{

	private Point center;
	
	
	public Point getCenter() {
		return center;
	}


	public void setCenter(Point center) {
		this.center = center;
	}


	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("drawing circle....");
		System.out.println("Circle center is ("+getCenter().getX()+","+getCenter().getY()+")");
		
	}

}
