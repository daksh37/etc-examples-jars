package com.pradeep.beans;

public interface Shape {

	public void draw();
}
